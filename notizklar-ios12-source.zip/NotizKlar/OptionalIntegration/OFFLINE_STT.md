# Optionale Offline-Spracherkennung

## Ziel

`LocalTranscriptionService` soll die lokale M4A-Aufnahme in deutschen Text umwandeln, ohne Audio an einen Dienst zu senden. Die App darf keine Apple-Speech-API als Ersatz verwenden: Apples klassische `SFSpeechRecognizer`-Dokumentation beschreibt ausdrücklich, dass sie Audio zur Verarbeitung an Apples Server senden kann.

## Vorgesehene Architektur

1. Eine iOS-kompatible Vosk-Laufzeit als Framework in das Xcode-Projekt einbinden.
2. Das Modell `vosk-model-small-de-0.15` auspacken und als Ordnerressource in den App-Bundle aufnehmen.
3. Die M4A-Datei mit `AVAudioFile` in Mono-PCM mit 16 kHz umwandeln.
4. Die PCM-Pakete der lokalen Vosk-Erkennung zuführen und die finalen Textsegmente sammeln.
5. Den Text erst dann in `MeetingNote.transcript` speichern und `LocalNoteComposer` ausführen.
6. Für jede Aufnahme eine Abbruchmöglichkeit und eine Speicherwarnung vorsehen; das iPod touch kann bei langen Dateien unter Speicherdruck geraten.

## Warum das nicht schon fest eingebunden ist

Die Vosk-iOS-Bibliothek und das deutsche Modell gehören als Binär- beziehungsweise Modellabhängigkeit in das App-Bundle. Beides wurde nicht ungeprüft in den Quellcode aufgenommen, weil das iPod touch mit iOS 12 nur begrenzten Arbeitsspeicher hat und zunächst eine Laufzeitmessung auf dem echten Zielgerät nötig ist. Die jetzige App bleibt in jedem Fall vollständig offline und zeigt transparent an, wenn die STT-Erweiterung noch fehlt.

## Prüfschritte nach der Integration

- 30 Sekunden leise, deutliche deutsche Sprache
- 3 Minuten normale Gesprächslautstärke
- eine Aufnahme mit zwei Sprechern und Hintergrundgeräusch
- Prüfung, ob die App nach der Transkription Speicher wieder freigibt

Ein gutes Ergebnis bei diesen kurzen Tests ist keine Zusage für eine hohe Genauigkeit bei langen, mehrsprachigen oder geräuschvollen Meetings.
