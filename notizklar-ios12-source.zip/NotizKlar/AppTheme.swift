import UIKit

enum AppTheme {
    static let accent = UIColor(red: 0.09, green: 0.39, blue: 0.44, alpha: 1.0)
    static let recording = UIColor(red: 0.75, green: 0.18, blue: 0.16, alpha: 1.0)
    static let border = UIColor(red: 0.78, green: 0.78, blue: 0.80, alpha: 1.0)
    static let mutedText = UIColor(red: 0.38, green: 0.38, blue: 0.42, alpha: 1.0)
    static let background = UIColor.white
    static let text = UIColor.black
}
