import UIKit

final class MeetingListViewController: UITableViewController {
    private var notes: [MeetingNote] = []
    private let store = MeetingStore.shared
    private let dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .short
        return formatter
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "NotizKlar"
        tableView.tableFooterView = emptyStateView()
        navigationItem.rightBarButtonItem = UIBarButtonItem(
            barButtonSystemItem: .add,
            target: self,
            action: #selector(addNote)
        )
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        do {
            notes = try store.load().sorted { $0.updatedAt > $1.updatedAt }
            tableView.reloadData()
            tableView.tableFooterView?.isHidden = !notes.isEmpty
        } catch {
            presentError(error)
        }
    }

    @objc private func addNote() {
        let alert = UIAlertController(title: "Neue Notiz", message: "Audio und Text werden nur lokal verarbeitet und gespeichert.", preferredStyle: .actionSheet)
        alert.addAction(UIAlertAction(title: "Aufnahme starten", style: .default) { [weak self] _ in
            self?.createNote(autoStartRecording: true)
        })
        alert.addAction(UIAlertAction(title: "Textnotiz anlegen", style: .default) { [weak self] _ in
            self?.createNote(autoStartRecording: false)
        })
        alert.addAction(UIAlertAction(title: "Abbrechen", style: .cancel))
        if let popover = alert.popoverPresentationController {
            popover.barButtonItem = navigationItem.rightBarButtonItem
        }
        present(alert, animated: true)
    }

    private func createNote(autoStartRecording: Bool) {
        let formatter = DateFormatter()
        formatter.dateFormat = "dd.MM. HH:mm"
        let note = MeetingNote(title: "Besprechung \(formatter.string(from: Date()))")
        showDetail(for: note, autoStartRecording: autoStartRecording)
    }

    private func showDetail(for note: MeetingNote, autoStartRecording: Bool = false) {
        let detail = MeetingDetailViewController(note: note, autoStartRecording: autoStartRecording)
        detail.onSave = { [weak self] changedNote in
            guard let self = self else { return }
            try self.upsert(changedNote)
        }
        navigationController?.pushViewController(detail, animated: true)
    }

    private func upsert(_ changedNote: MeetingNote) throws {
        var candidateNotes = notes
        if let index = candidateNotes.firstIndex(where: { $0.id == changedNote.id }) {
            candidateNotes[index] = changedNote
        } else {
            candidateNotes.append(changedNote)
        }
        candidateNotes.sort { $0.updatedAt > $1.updatedAt }
        try store.save(candidateNotes)
        notes = candidateNotes
        tableView.reloadData()
        tableView.tableFooterView?.isHidden = !notes.isEmpty
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return notes.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let note = notes[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: "NoteCell")
            ?? UITableViewCell(style: .subtitle, reuseIdentifier: "NoteCell")
        cell.textLabel?.text = note.title
        cell.textLabel?.font = UIFont.preferredFont(forTextStyle: .headline)
        let audioText = note.hasAudio ? "Aufnahme \(note.formattedDuration)" : "Textnotiz"
        cell.detailTextLabel?.text = "\(dateFormatter.string(from: note.updatedAt)) · \(audioText)"
        cell.detailTextLabel?.font = UIFont.preferredFont(forTextStyle: .subheadline)
        cell.accessoryType = .disclosureIndicator
        return cell
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        showDetail(for: notes[indexPath.row])
    }

    override func tableView(
        _ tableView: UITableView,
        commit editingStyle: UITableViewCell.EditingStyle,
        forRowAt indexPath: IndexPath
    ) {
        guard editingStyle == .delete else { return }
        let removedNote = notes[indexPath.row]
        var candidateNotes = notes
        candidateNotes.remove(at: indexPath.row)
        do {
            try store.save(candidateNotes)
            notes = candidateNotes
            tableView.deleteRows(at: [indexPath], with: .automatic)
            tableView.tableFooterView?.isHidden = !notes.isEmpty
            do {
                try store.deleteAudio(named: removedNote.audioFileName)
            } catch {
                presentError(error)
            }
        } catch {
            presentError(error)
        }
    }

    private func emptyStateView() -> UIView {
        let label = UILabel()
        label.numberOfLines = 0
        label.textAlignment = .center
        label.textColor = AppTheme.mutedText
        label.font = UIFont.preferredFont(forTextStyle: .body)
        label.text = "Noch keine Notizen.\nTippe auf +, um eine lokale Aufnahme oder Textnotiz anzulegen."
        label.frame = CGRect(x: 24, y: 90, width: view.bounds.width - 48, height: 80)
        return label
    }

    private func presentError(_ error: Error) {
        let alert = UIAlertController(title: "Speichern nicht möglich", message: error.localizedDescription, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
}
