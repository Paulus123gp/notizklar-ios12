import UIKit

final class MeetingDetailViewController: UIViewController, UITextViewDelegate {
    var onSave: ((MeetingNote) throws -> Void)?

    private var note: MeetingNote
    private let autoStartRecording: Bool
    private let audioRecorder = AudioRecorderService()
    private let localComposer = LocalNoteComposer()
    private let transcriptionService = LocalTranscriptionService()
    private var timer: Timer?
    private var pendingRecordingURL: URL?

    private let scrollView = UIScrollView()
    private let stackView = UIStackView()
    private let titleField = UITextField()
    private let recordingButton = UIButton(type: .system)
    private let recordingStateLabel = UILabel()
    private let transcriptView = UITextView()
    private let structureButton = UIButton(type: .system)
    private let summaryLabel = UILabel()
    private let transcribeButton = UIButton(type: .system)

    init(note: MeetingNote, autoStartRecording: Bool) {
        self.note = note
        self.autoStartRecording = autoStartRecording
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    deinit {
        timer?.invalidate()
        if audioRecorder.isRecording {
            _ = audioRecorder.stopRecording()
        }
        if let url = pendingRecordingURL {
            try? FileManager.default.removeItem(at: url)
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Notiz"
        view.backgroundColor = AppTheme.background
        setupNavigation()
        setupLayout()
        loadEditorFields()
        refreshView()
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if autoStartRecording && !note.hasAudio && !audioRecorder.isRecording {
            startRecording()
        }
    }

    private func setupNavigation() {
        navigationItem.leftBarButtonItem = UIBarButtonItem(
            title: "Zurück",
            style: .plain,
            target: self,
            action: #selector(save)
        )
        navigationItem.rightBarButtonItem = UIBarButtonItem(
            barButtonSystemItem: .save,
            target: self,
            action: #selector(save)
        )
    }

    private func setupLayout() {
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        stackView.translatesAutoresizingMaskIntoConstraints = false
        stackView.axis = .vertical
        stackView.spacing = 14
        stackView.alignment = .fill
        view.addSubview(scrollView)
        scrollView.addSubview(stackView)

        NSLayoutConstraint.activate([
            scrollView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor),
            scrollView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor),
            scrollView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            scrollView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            stackView.leadingAnchor.constraint(equalTo: scrollView.contentLayoutGuide.leadingAnchor, constant: 16),
            stackView.trailingAnchor.constraint(equalTo: scrollView.contentLayoutGuide.trailingAnchor, constant: -16),
            stackView.topAnchor.constraint(equalTo: scrollView.contentLayoutGuide.topAnchor, constant: 20),
            stackView.bottomAnchor.constraint(equalTo: scrollView.contentLayoutGuide.bottomAnchor, constant: -24),
            stackView.widthAnchor.constraint(equalTo: scrollView.frameLayoutGuide.widthAnchor, constant: -32)
        ])

        titleField.borderStyle = .roundedRect
        titleField.font = UIFont.preferredFont(forTextStyle: .title2)
        titleField.placeholder = "Titel der Besprechung"
        titleField.accessibilityLabel = "Titel der Besprechung"

        recordingButton.titleLabel?.font = UIFont.preferredFont(forTextStyle: .headline)
        recordingButton.backgroundColor = AppTheme.accent
        recordingButton.setTitleColor(.white, for: .normal)
        recordingButton.layer.cornerRadius = 8
        recordingButton.heightAnchor.constraint(equalToConstant: 48).isActive = true
        recordingButton.addTarget(self, action: #selector(toggleRecording), for: .touchUpInside)

        recordingStateLabel.font = UIFont.preferredFont(forTextStyle: .subheadline)
        recordingStateLabel.textAlignment = .center
        recordingStateLabel.textColor = AppTheme.mutedText

        transcribeButton.setTitle("Audio-zu-Text: Offline-Modell noch nicht installiert", for: .normal)
        transcribeButton.titleLabel?.font = UIFont.preferredFont(forTextStyle: .subheadline)
        transcribeButton.isEnabled = transcriptionService.isAvailable
        transcribeButton.alpha = transcriptionService.isAvailable ? 1.0 : 0.5
        transcribeButton.addTarget(self, action: #selector(transcribeAudio), for: .touchUpInside)

        let transcriptHeader = sectionLabel("Transkript")
        transcriptView.font = UIFont.preferredFont(forTextStyle: .body)
        transcriptView.isScrollEnabled = false
        transcriptView.layer.borderColor = AppTheme.border.cgColor
        transcriptView.layer.borderWidth = 1
        transcriptView.layer.cornerRadius = 8
        transcriptView.textContainerInset = UIEdgeInsets(top: 10, left: 8, bottom: 10, right: 8)
        transcriptView.heightAnchor.constraint(greaterThanOrEqualToConstant: 170).isActive = true
        transcriptView.accessibilityLabel = "Transkript bearbeiten"
        transcriptView.delegate = self

        structureButton.setTitle("Text lokal strukturieren", for: .normal)
        structureButton.titleLabel?.font = UIFont.preferredFont(forTextStyle: .headline)
        structureButton.addTarget(self, action: #selector(structureTranscript), for: .touchUpInside)

        let resultHeader = sectionLabel("Ergebnis")
        summaryLabel.numberOfLines = 0
        summaryLabel.font = UIFont.preferredFont(forTextStyle: .body)
        summaryLabel.textColor = AppTheme.text

        [titleField, recordingButton, recordingStateLabel, transcribeButton, transcriptHeader, transcriptView, structureButton, resultHeader, summaryLabel].forEach {
            stackView.addArrangedSubview($0)
        }
    }

    private func sectionLabel(_ text: String) -> UILabel {
        let label = UILabel()
        label.text = text
        label.font = UIFont.preferredFont(forTextStyle: .headline)
        return label
    }

    private func refreshView() {
        recordingButton.setTitle(audioRecorder.isRecording ? "Aufnahme stoppen" : "Aufnahme starten", for: .normal)
        recordingButton.backgroundColor = audioRecorder.isRecording ? AppTheme.recording : AppTheme.accent
        if audioRecorder.isRecording {
            recordingStateLabel.text = "Aufnahme läuft · \(format(audioRecorder.elapsed))"
        } else if note.hasAudio {
            recordingStateLabel.text = "Lokale Aufnahme vorhanden · \(note.formattedDuration)"
        } else {
            recordingStateLabel.text = "Noch keine Aufnahme"
        }
        summaryLabel.text = renderedStructuredText()
    }

    private func loadEditorFields() {
        titleField.text = note.title
        transcriptView.text = note.transcript
    }

    @objc private func toggleRecording() {
        audioRecorder.isRecording ? stopRecording() : startRecording()
    }

    private func startRecording() {
        audioRecorder.requestPermission { [weak self] result in
            guard let self = self else { return }
            switch result {
            case .failure(let error):
                self.showError(error)
            case .success:
                do {
                    let url = try MeetingStore.shared.newRecordingURL(for: self.note.id)
                    do {
                    try self.audioRecorder.startRecording(to: url)
                    self.pendingRecordingURL = url
                    self.navigationController?.interactivePopGestureRecognizer?.isEnabled = false
                        try MeetingStore.shared.excludeFromBackup(at: url)
                    } catch {
                        if self.audioRecorder.isRecording {
                            _ = self.audioRecorder.stopRecording()
                        }
                        self.pendingRecordingURL = nil
                        try? FileManager.default.removeItem(at: url)
                        throw error
                    }
                    self.timer?.invalidate()
                    self.timer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { [weak self] _ in
                        self?.refreshView()
                    }
                    self.refreshView()
                } catch {
                    if self.audioRecorder.isRecording {
                        _ = self.audioRecorder.stopRecording()
                    }
                    self.showError(error)
                }
            }
        }
    }

    @discardableResult
    private func stopRecording() -> Bool {
        applyEditorChanges()
        let duration = audioRecorder.stopRecording()
        navigationController?.interactivePopGestureRecognizer?.isEnabled = true
        timer?.invalidate()
        timer = nil

        guard let newURL = pendingRecordingURL else {
            refreshView()
            return true
        }
        pendingRecordingURL = nil

        let previousFileName = note.audioFileName
        let previousDuration = note.recordingDuration
        note.audioFileName = newURL.lastPathComponent
        note.recordingDuration = duration
        note.updatedAt = Date()

        do {
            try persist()
            if previousFileName != note.audioFileName {
                try? MeetingStore.shared.deleteAudio(named: previousFileName)
            }
            refreshView()
            return true
        } catch {
            note.audioFileName = previousFileName
            note.recordingDuration = previousDuration
            try? FileManager.default.removeItem(at: newURL)
            refreshView()
            showError(error)
            return false
        }
    }

    @objc private func structureTranscript() {
        applyEditorChanges()
        let structured = localComposer.compose(from: note.transcript)
        note.summary = structured.summary
        note.keyPoints = structured.keyPoints
        note.todos = structured.todos
        note.updatedAt = Date()
        do {
            try persist()
            refreshView()
        } catch {
            showError(error)
        }
    }

    @objc private func transcribeAudio() {
        guard let name = note.audioFileName else {
            showMessage(title: "Keine Aufnahme", message: "Starte zuerst eine lokale Audioaufnahme.")
            return
        }
        transcriptionService.transcribe(audioAt: MeetingStore.shared.audioURL(for: name)) { [weak self] result in
            DispatchQueue.main.async {
                switch result {
                case .success(let text):
                    self?.transcriptView.text = text
                    self?.structureTranscript()
                case .failure(let error):
                    self?.showMessage(title: "Offline-Transkription", message: error.localizedDescription)
                }
            }
        }
    }

    @objc private func save() {
        applyEditorChanges()
        if audioRecorder.isRecording {
            if stopRecording() {
                navigationController?.popViewController(animated: true)
            }
            return
        }
        do {
            try persist()
            navigationController?.popViewController(animated: true)
        } catch {
            showError(error)
        }
    }

    private func applyEditorChanges() {
        let enteredTitle = (titleField.text ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        note.title = enteredTitle.isEmpty ? "Neue Notiz" : enteredTitle
        note.transcript = transcriptView.text.trimmingCharacters(in: .whitespacesAndNewlines)
        note.updatedAt = Date()
    }

    private func persist() throws {
        guard let onSave = onSave else { return }
        try onSave(note)
    }

    private func renderedStructuredText() -> String {
        var sections: [String] = []
        if !note.summary.isEmpty {
            sections.append("Zusammenfassung\n\(note.summary)")
        }
        if !note.keyPoints.isEmpty {
            sections.append("Kernpunkte\n" + note.keyPoints.map { "• \($0)" }.joined(separator: "\n"))
        }
        if !note.todos.isEmpty {
            sections.append("Aufgaben\n" + note.todos.map { "□ \($0)" }.joined(separator: "\n"))
        }
        return sections.isEmpty ? "Nach dem Strukturieren erscheinen hier Zusammenfassung, Kernpunkte und Aufgaben." : sections.joined(separator: "\n\n")
    }

    private func format(_ interval: TimeInterval) -> String {
        let seconds = max(0, Int(interval.rounded()))
        return String(format: "%02d:%02d", seconds / 60, seconds % 60)
    }

    private func showError(_ error: Error) {
        showMessage(title: "Speichern oder Aufnahme nicht möglich", message: error.localizedDescription)
    }

    private func showMessage(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
}
