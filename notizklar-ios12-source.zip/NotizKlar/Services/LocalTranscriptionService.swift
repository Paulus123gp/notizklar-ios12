import Foundation

/// Schnittstelle für eine vollständig lokale Speech-to-Text-Engine.
///
/// Das MVP bindet absichtlich keine Apple-Speech- oder Cloud-API ein. Diese könnten
/// Audio an externe Server senden und würden die Offline-Anforderung verletzen.
/// Eine Vosk- oder vergleichbare Engine kann diese Klasse ersetzen, ohne die UI
/// oder die Speicherung zu verändern.
final class LocalTranscriptionService {
    enum TranscriptionError: LocalizedError {
        case offlineEngineNotInstalled

        var errorDescription: String? {
            switch self {
            case .offlineEngineNotInstalled:
                return "Die lokale Spracherkennungs-Engine und das deutsche Modell sind noch nicht eingebunden. Du kannst das Transkript jetzt manuell eintragen; die Anleitung für die Offline-Integration liegt dem Projekt bei."
            }
        }
    }

    var isAvailable: Bool {
        return false
    }

    func transcribe(audioAt url: URL, completion: @escaping (Result<String, Error>) -> Void) {
        completion(.failure(TranscriptionError.offlineEngineNotInstalled))
    }
}
