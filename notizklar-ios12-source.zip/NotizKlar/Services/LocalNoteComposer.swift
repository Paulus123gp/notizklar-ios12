import Foundation

struct StructuredNote {
    let summary: String
    let keyPoints: [String]
    let todos: [String]
}

/// Bewusst deterministisch und vollständig lokal. Es werden keine Daten übertragen.
final class LocalNoteComposer {
    func compose(from rawText: String) -> StructuredNote {
        let sentences = splitIntoSentences(rawText)
        guard !sentences.isEmpty else {
            return StructuredNote(
                summary: "Noch kein Transkript vorhanden.",
                keyPoints: [],
                todos: []
            )
        }

        let summary = sentences.prefix(2).joined(separator: " ")
        let keyPointKeywords = ["wichtig", "entschieden", "beschlossen", "ziel", "priorität", "problem", "risiko", "nächster schritt"]
        let todoKeywords = ["todo", "aufgabe", "soll", "muss", "bitte", "übernimmt", "bis ", "erledigen", "prüfen"]

        let highlighted = sentences.filter { sentence in
            let lowercased = sentence.lowercased()
            return keyPointKeywords.contains(where: lowercased.contains)
        }
        let keyPoints = Array((highlighted.isEmpty ? sentences : highlighted).prefix(5))

        let explicitTodos = rawText
            .components(separatedBy: .newlines)
            .compactMap { line -> String? in
                let trimmed = line.trimmingCharacters(in: .whitespacesAndNewlines)
                let lowercased = trimmed.lowercased()
                if lowercased.hasPrefix("todo:") || lowercased.hasPrefix("aufgabe:") {
                    let value = trimmed.components(separatedBy: ":").dropFirst().joined(separator: ":")
                        .trimmingCharacters(in: .whitespacesAndNewlines)
                    return value.isEmpty ? nil : value
                }
                return nil
            }
        let inferredTodos = sentences.filter { sentence in
            let lowercased = sentence.lowercased()
            return todoKeywords.contains(where: lowercased.contains)
        }
        let todos = unique(Array((explicitTodos + inferredTodos).prefix(8)))

        return StructuredNote(summary: summary, keyPoints: keyPoints, todos: todos)
    }

    private func splitIntoSentences(_ text: String) -> [String] {
        let normalized = text
            .replacingOccurrences(of: "\n", with: " ")
            .replacingOccurrences(of: "  ", with: " ")
        return normalized
            .components(separatedBy: CharacterSet(charactersIn: ".!?"))
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { $0.count > 2 }
    }

    private func unique(_ values: [String]) -> [String] {
        var seen = Set<String>()
        return values.filter { seen.insert($0.lowercased()).inserted }
    }
}
