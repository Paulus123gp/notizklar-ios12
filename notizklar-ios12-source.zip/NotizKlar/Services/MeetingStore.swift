import Foundation

final class MeetingStore {
    enum StoreError: LocalizedError {
        case unreadableNotes
        case invalidNotes

        var errorDescription: String? {
            switch self {
            case .unreadableNotes:
                return "Die gespeicherten Notizen konnten nicht gelesen werden. Es wurde nichts überschrieben."
            case .invalidNotes:
                return "Die gespeicherten Notizen sind nicht lesbar. Es wurde nichts überschrieben."
            }
        }
    }

    static let shared = MeetingStore()

    private let fileManager = FileManager.default
    private let notesFileName = "meeting-notes.json"

    private init() {}

    func load() throws -> [MeetingNote] {
        let url = notesURL()
        guard fileManager.fileExists(atPath: url.path) else { return [] }
        guard let data = try? Data(contentsOf: url) else {
            throw StoreError.unreadableNotes
        }
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        guard let notes = try? decoder.decode([MeetingNote].self, from: data) else {
            throw StoreError.invalidNotes
        }
        return notes
    }

    func save(_ notes: [MeetingNote]) throws {
        let encoder = JSONEncoder()
        encoder.outputFormatting = .prettyPrinted
        encoder.dateEncodingStrategy = .iso8601
        let data = try encoder.encode(notes)
        try ensureDocumentsDirectory()
        let url = notesURL()
        try data.write(to: url, options: .atomic)
        try excludeFromBackup(at: url)
    }

    func audioURL(for fileName: String) -> URL {
        return recordingsDirectoryURL().appendingPathComponent(fileName)
    }

    func newRecordingURL(for noteID: UUID) throws -> URL {
        try ensureRecordingsDirectory()
        let name = "aufnahme-\(noteID.uuidString)-\(UUID().uuidString).m4a"
        return recordingsDirectoryURL().appendingPathComponent(name)
    }

    func deleteAudio(named fileName: String?) throws {
        guard let fileName = fileName else { return }
        let url = audioURL(for: fileName)
        guard fileManager.fileExists(atPath: url.path) else { return }
        try fileManager.removeItem(at: url)
    }

    func excludeFromBackup(at url: URL) throws {
        var values = URLResourceValues()
        values.isExcludedFromBackup = true
        var mutableURL = url
        try mutableURL.setResourceValues(values)
    }

    private func notesURL() -> URL {
        return documentsDirectoryURL().appendingPathComponent(notesFileName)
    }

    private func recordingsDirectoryURL() -> URL {
        return documentsDirectoryURL().appendingPathComponent("Aufnahmen", isDirectory: true)
    }

    private func documentsDirectoryURL() -> URL {
        return fileManager.urls(for: .documentDirectory, in: .userDomainMask)[0]
    }

    private func ensureDocumentsDirectory() throws {
        try fileManager.createDirectory(at: documentsDirectoryURL(), withIntermediateDirectories: true, attributes: nil)
    }

    private func ensureRecordingsDirectory() throws {
        try ensureDocumentsDirectory()
        try fileManager.createDirectory(at: recordingsDirectoryURL(), withIntermediateDirectories: true, attributes: nil)
    }
}
