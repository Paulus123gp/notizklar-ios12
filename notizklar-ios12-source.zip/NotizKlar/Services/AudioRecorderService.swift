import AVFoundation

final class AudioRecorderService: NSObject {
    enum RecorderError: LocalizedError {
        case permissionDenied
        case cannotCreateFile
        case couldNotStartRecording

        var errorDescription: String? {
            switch self {
            case .permissionDenied:
                return "Der Mikrofonzugriff wurde nicht erlaubt. Bitte aktiviere ihn in den iOS-Einstellungen."
            case .cannotCreateFile:
                return "Die Aufnahmedatei konnte nicht angelegt werden."
            case .couldNotStartRecording:
                return "Die Aufnahme konnte nicht gestartet werden."
            }
        }
    }

    private var recorder: AVAudioRecorder?
    private var startedAt: Date?

    var isRecording: Bool {
        return recorder?.isRecording ?? false
    }

    var elapsed: TimeInterval {
        guard let startedAt = startedAt else { return 0 }
        return Date().timeIntervalSince(startedAt)
    }

    func requestPermission(completion: @escaping (Result<Void, Error>) -> Void) {
        AVAudioSession.sharedInstance().requestRecordPermission { allowed in
            DispatchQueue.main.async {
                allowed ? completion(.success(())) : completion(.failure(RecorderError.permissionDenied))
            }
        }
    }

    func startRecording(to url: URL) throws {
        let session = AVAudioSession.sharedInstance()
        try session.setCategory(.record, mode: .default, options: [])
        try session.setActive(true, options: [])

        let settings: [String: Any] = [
            AVFormatIDKey: Int(kAudioFormatMPEG4AAC),
            AVSampleRateKey: 16_000,
            AVNumberOfChannelsKey: 1,
            AVEncoderAudioQualityKey: AVAudioQuality.high.rawValue,
            AVEncoderBitRateKey: 32_000
        ]

        recorder = try AVAudioRecorder(url: url, settings: settings)
        recorder?.prepareToRecord()
        guard recorder?.record() == true else {
            recorder = nil
            throw RecorderError.couldNotStartRecording
        }
        startedAt = Date()
    }

    @discardableResult
    func stopRecording() -> TimeInterval {
        let duration = recorder?.currentTime ?? elapsed
        recorder?.stop()
        recorder = nil
        startedAt = nil
        try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
        return duration
    }
}
