import Foundation

struct MeetingNote: Codable, Equatable {
    let id: UUID
    var title: String
    let createdAt: Date
    var updatedAt: Date
    var audioFileName: String?
    var recordingDuration: TimeInterval
    var transcript: String
    var summary: String
    var keyPoints: [String]
    var todos: [String]

    init(title: String) {
        id = UUID()
        self.title = title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? "Neue Notiz" : title
        createdAt = Date()
        updatedAt = Date()
        audioFileName = nil
        recordingDuration = 0
        transcript = ""
        summary = ""
        keyPoints = []
        todos = []
    }

    var hasAudio: Bool {
        return audioFileName != nil
    }

    var formattedDuration: String {
        let totalSeconds = max(0, Int(recordingDuration.rounded()))
        return String(format: "%02d:%02d", totalSeconds / 60, totalSeconds % 60)
    }
}
