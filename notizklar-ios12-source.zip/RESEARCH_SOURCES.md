# Verwendete technische Quellen

- Apple dokumentiert für persönliche Teams, dass die Gerätebereitstellungsprofile sieben Tage nach Ausstellung ablaufen: [Developer account overview](https://developer.apple.com/help/account/basics/about-your-developer-account/).
- Apple beschreibt die Geräte-Registrierung über Xcode, den IPA-Export und die Installation auf registrierten Geräten über Device Hub oder Apple Configurator: [Distributing your app to registered devices](https://developer.apple.com/documentation/xcode/distributing-your-app-to-registered-devices).
- Die Expo-Dokumentation nennt derzeit iOS 16.4+ als Mindestversion des Expo SDK; es passt daher nicht zum iOS-12-Zielgerät: [Expo FAQ](https://docs.expo.dev/faq/).
- Apples klassische Speech-Erkennung verarbeitet Audio laut Dokumentation über Apples Server: [Asking Permission to Use Speech Recognition](https://developer.apple.com/documentation/speech/asking-permission-to-use-speech-recognition).
- Vosk beschreibt sich als offlinefähige Spracherkennung für iOS und nennt kleine Modelle für mobile Geräte. Das Modell `vosk-model-small-de-0.15` ist mit 45 MB gelistet: [Vosk](https://alphacephei.com/vosk/) und [Vosk Models](https://alphacephei.com/vosk/models).

- GitHub Actions: Standard-Runner sind für öffentliche Repositories kostenlos; private Repositories haben monatliche Kontingente: [GitHub Actions billing](https://docs.github.com/billing/managing-billing-for-github-actions/about-billing-for-github-actions).
- Sideloadly nennt Windows-Unterstützung, iOS 7+ und Signierung mit kostenlosen Apple-IDs; Gratis-Signaturen gelten sieben Tage: [Sideloadly](https://sideloadly.io/index.html).
- Sideloadly dokumentiert die Windows-Treiberanforderung und empfiehlt bei Erkennungsproblemen die Web-Version von iTunes statt der Microsoft-Store-Version: [Sideloadly FAQ](https://sideloadly.io/faq.html).
